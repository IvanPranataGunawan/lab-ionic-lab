export class Books{
    constructor(
        public id: string,
        public imageUrl: string,
        public title: string,
        public desc: string,
        public kategori: string,
        public ket: boolean
    ){}
}