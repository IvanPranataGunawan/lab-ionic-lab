import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-ukm',
  templateUrl: './list-ukm.page.html',
  styleUrls: ['./list-ukm.page.scss'],
})
export class ListUKMPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
